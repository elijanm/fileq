from pydantic import BaseModel

class TicketingModel(BaseModel):
    id: str
    created_at: str
    data: dict
