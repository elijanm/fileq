from fastapi import APIRouter
from jinja2 import Environment, FileSystemLoader
from pathlib import Path
from routes.auth import get_current_user,checker,Depends,SessionInfo

def init_plugin():
    router = APIRouter()
    templates = Path(__file__).parent / "templates"
    env = Environment(loader=FileSystemLoader(templates))

    @router.get("/")
    @checker.requires_role("admin")
    async def dashboard(user:SessionInfo=Depends(get_current_user)):
        tmpl = env.get_template("dashboard.html")
        return tmpl.render(title="Ticketing Plugin")

    @router.post("/create")
    @checker.requires_role("admin")
    async def create_item(item: dict,user:SessionInfo=Depends(get_current_user)):
        return {"status": "created", "plugin": "ticketing", "item": item}

    return {"router": router}
