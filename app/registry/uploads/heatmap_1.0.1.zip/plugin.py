from fastapi import APIRouter, Request
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from datetime import datetime
from jinja2 import Environment, FileSystemLoader

router = APIRouter()
plugin_dir = Path(__file__).parent
static_dir = plugin_dir / "static"
templates_dir = plugin_dir / "templates"

env = Environment(loader=FileSystemLoader(templates_dir))

# Serve static JS tracker
router.mount("/static", StaticFiles(directory=static_dir), name="heatmap-static")

# --- API routes ---
@router.post("/log")
async def log_event(request: Request):
    db = request.app.state.db
    data = await request.json()
    data["timestamp"] = datetime.utcnow().isoformat()
    await db["heatmap_events"].insert_one(data)
    return {"status": "ok"}

@router.get("/heatmap", response_class=HTMLResponse)
async def view_heatmap(request: Request):
    db = request.app.state.db
    events = await db["heatmap_events"].find({"type": "click"}).to_list(1000)
    template = env.get_template("heatmap_dashboard.html")
    return template.render(events=events)

# --- Initialize plugin ---
def init_plugin():
    return {"router": router}
